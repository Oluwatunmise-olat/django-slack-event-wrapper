import json
from rest_framework.response import Response
from rest_framework.views import APIView
from django.conf import settings

from django_slack_event_wrapper.events import slack_event_trigger, slash_event_trigger

try:
    settings.VERIFICATION_TOKEN
    settings.APP_ID
except Exception as e:
    raise Exception("seems like your configurations aren't rightly done")


class SlackEventView(APIView):
    def post(self, request, *args, **kwargs):
        payload = request.data
        print(payload)
        if payload['type'] == 'url_verification':
            return Response({'challenge': payload['challenge']}, status="200")
        # for verification that the event is for our bot
        token = payload['token']
        api_app_id = payload['api_app_id']

        # verify that the token matches what was issued to your app by slack (signing secret)
        if not token == settings.VERIFICATION_TOKEN and api_app_id != settings.APP_ID:
            return Response({'error': 'Event is not for our Bot or check that your verification token and app id are correct.'}, 403)
        # work space event occured
        team_id = payload['team_id']
        # contains field representing event occuring
        event = payload['event']
        event_type = event['type']
        if not event_type == 'app_rate_limited':
            return slack_event_trigger(team_id=team_id, event_type=event_type, event=event)
        return Response({})


class SlashCommandView(APIView):
    def post(self, request):
        received_data = request.data.dict()
        user_id = received_data.get('user_id')
        channel_id = received_data.get('channel_id')
        slash_event_trigger(user_id=user_id, channel_id=channel_id, slash_event_data=received_data)
        return Response(status="200")
