This is a django wrapper to handle slack events and slash commands.
Note: it doesn't perform verification but receives slack events, slash commands and delivers gracefully with the events.  
